﻿using QLSV.Data;
using QLSV.Helpers;
using QLSV.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLSV.Forms.Catalog
{
    public partial class frmGiangVien : Form
    {
        private readonly GiangVienService _svc = new GiangVienService();
        private bool _dangThem = true;

        public frmGiangVien()
        {
            InitializeComponent();
            dgvGiangVien.AutoGenerateColumns = false;
        }


        private void frmGiangVien_Load(object sender, EventArgs e)
        {
            btnThem.Enabled = btnLuu.Enabled = btnXoa.Enabled =
                SessionManager.HasPermission(MaChucNang.QL_GIANGVIEN);

            var ds = new KhoaService().GetAll();
            //MessageBox.Show("Số lượng khoa: " + ds.Count);

            // ComboBox khoa trực thuộc
            cboKhoa.DataSource = null;
            cboKhoa.DisplayMember = "TenKhoa";
            cboKhoa.ValueMember = "MaKhoa";
            cboKhoa.DataSource = new List<Khoa>(ds);

            var loc = new List<Khoa>(ds);

            loc.Insert(0, new Khoa
            {
                MaKhoa = "",
                TenKhoa = "-- Tất cả --"
            });

            cboLocKhoa.DataSource = null;
            cboLocKhoa.DisplayMember = "TenKhoa";
            cboLocKhoa.ValueMember = "MaKhoa";
            cboLocKhoa.DataSource = loc;
            LoadData();
            LamMoi();
        }


        // Từ khóa và khoa cùng áp dụng
        private void LoadData()
        {
            string khoa = cboLocKhoa.SelectedValue == null ? "" : cboLocKhoa.SelectedValue.ToString();
            dgvGiangVien.DataSource = _svc.Search(txtTimKiem.Text.Trim(), khoa);
        }

        private void btnTim_Click(object sender, EventArgs e) { 
            LoadData(); 
        }
        private void cboLocKhoa_SelectionChangeCommitted(object sender, EventArgs e) { LoadData(); }

        private void LamMoi()
        {
            txtMaGV.Clear();
            txtHoTen.Clear();
            txtEmail.Clear();
            txtSDT.Clear();
            txtMaGV.ReadOnly = false;
            if (cboKhoa.Items.Count > 0) cboKhoa.SelectedIndex = 0;
            _dangThem = true;
            txtMaGV.Focus();
        }

        private void dgvGiangVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) 
                return;
            var g = dgvGiangVien.Rows[e.RowIndex].DataBoundItem as GiangVien;
            if (g == null) 
                return;
            txtMaGV.Text = g.MaGV;
            txtMaGV.ReadOnly = true;
            txtHoTen.Text = g.HoTen;
            txtEmail.Text = g.Email;
            txtSDT.Text = g.SDT;
            cboKhoa.SelectedValue = g.MaKhoa;
            _dangThem = false;
        }

        private void btnThem_Click(object sender, EventArgs e) {
            var g = new GiangVien
            {
                MaGV = txtMaGV.Text.Trim(),
                HoTen = txtHoTen.Text.Trim(),
                Email = txtEmail.Text.Trim(),
                SDT = txtSDT.Text.Trim(),
                MaKhoa = cboKhoa.SelectedValue == null ? "" : cboKhoa.SelectedValue.ToString().Trim()
            };

            Result r = _svc.ThemMoi(g);
            HienThongBao(r);

            if (r.Success)
            {
                LoadData();
                LamMoi();
            }
        }
        private void btnLamMoi_Click(object sender, EventArgs e) { 
            txtTimKiem.Clear(); LamMoi(); LoadData(); 
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            var g = new GiangVien
            {
                MaGV = txtMaGV.Text.Trim(),
                HoTen = txtHoTen.Text.Trim(),
                Email = txtEmail.Text.Trim(),
                SDT = txtSDT.Text.Trim(),
                MaKhoa = cboKhoa.SelectedValue == null ? "" : cboKhoa.SelectedValue.ToString()
            };
            Result r = _svc.Luu(g);
            HienThongBao(r);
            if (r.Success) { LoadData(); LamMoi(); }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaGV.Text)) { 
                MessageBox.Show("Hãy chọn giảng viên cần xóa."); 
                return; 
            }
            if (MessageBox.Show("Xóa giảng viên " + txtMaGV.Text + "?", "Xác nhận",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) 
                return;
            Result r = _svc.Xoa(txtMaGV.Text.Trim());
            HienThongBao(r);
            if (r.Success) { LoadData(); LamMoi(); }
        }

        private void HienThongBao(Result r)
        {
            MessageBox.Show(r.Message, "Thông báo", MessageBoxButtons.OK,
                r.Success ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        }

        private void cboKhoa_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dgvGiangVien_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
